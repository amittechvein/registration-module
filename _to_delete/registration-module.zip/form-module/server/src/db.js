require('dotenv').config();
const { Sequelize } = require('sequelize');

const dialect = process.env.DB_DIALECT || 'sqlite';

const sequelize =
  dialect === 'mysql'
    ? new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASS, {
        host: process.env.DB_HOST || 'localhost',
        port: Number(process.env.DB_PORT || 3306),
        dialect: 'mysql',
        logging: false,
      })
    : new Sequelize({
        dialect: 'sqlite',
        storage: process.env.DB_STORAGE || './registration.sqlite',
        logging: false,
      });

module.exports = sequelize;
